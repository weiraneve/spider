import asyncio
import danmaku

async def printer(q):
    while True:
        m = await q.get()
        if m['msg_type'] == 'danmaku':
            print(f'{m["nn"]}：{m["txt"]}')#拆取正文


async def main():
    q = asyncio.Queue()
    dmc = danmaku.DanmakuClient('https://douyu.com/48699', q)#输入直播网址
    asyncio.create_task(printer(q))
    await dmc.start()

asyncio.run(main()) #jupyter 只需要await main()  ide需要 asyncio.run(main())